enum MenuState { home, favorite, setting }

enum ResultState { Loading, NoData, HasData, Error }
